"""
Client Hunter : ยิง request แย่งคูปองไปยัง Server ของเพื่อน

หมายเหตุเรื่อง port : ไฟล์นี้ "ไม่ได้เปิด port" ของตัวเองเลย
มันเป็นแค่สคริปต์ที่ยิง HTTP ออกไปข้างนอก (ไม่ใช่ uvicorn เหมือน Week5)
เพราะฉะนั้นเปิดพร้อมกันกี่หน้าต่างก็ได้ ไม่มีทางชนกันเอง
port ที่ต้องระวังไม่ให้ทับ มีแค่ฝั่ง Server เท่านั้น

วิธีรัน
    python client.py                                    # ใช้ค่า default ข้างล่าง
    python client.py Student_01                         # ระบุชื่อตัวเอง
    python client.py Student_01 172.20.56.117 8088      # ยิงไปเครื่องเพื่อน
    python client.py Student_01 localhost 8089          # ยิงไปตัวที่มี Lock
"""
import sys
import asyncio
import httpx

# ── ค่า default (ถ้าไม่ได้ใส่ argument ตอนรัน จะใช้ชุดนี้) ──────────────
SERVER_IP = "localhost"
PORT = "8089"
MY_STUDENT_ID = "6710301006"

# รับค่าจาก command line มาทับค่า default
# argv[1] = ชื่อนักเรียน, argv[2] = IP ของ Server, argv[3] = port
if len(sys.argv) > 1:
    MY_STUDENT_ID = sys.argv[1]
if len(sys.argv) > 2:
    SERVER_IP = sys.argv[2]
if len(sys.argv) > 3:
    PORT = sys.argv[3]

SERVER_URL = f"http://{SERVER_IP}:{PORT}"


async def hunt_coupons():
    async with httpx.AsyncClient() as client:
        print(f"[{MY_STUDENT_ID}] เริ่มต้นภารกิจล่าคูปอง... (เป้าหมาย {SERVER_URL})")

        # ยิงขอคูปองต่อเนื่องสูงสุด 5 ครั้ง เพื่อพยายามเก็บให้ได้ครบ 2 ใบ
        for attempt in range(1, 6):
            try:
                res = await client.post(
                    f"{SERVER_URL}/claim",
                    json={"student_id": MY_STUDENT_ID},
                    timeout=5.0
                )

                data = res.json()
                status = data.get("status")

                print(f"  — ครั้งที่ {attempt}: [{status}] -> {data.get('message', data.get('claimed_coupon'))}")

                # หากได้ครบ 2 ใบ หรือคูปองหมดแล้ว ให้หยุดยิงทันที
                if status in ["LIMIT_REACHED", "OUT_OF_STOCK"]:
                    break

            except httpx.RequestError as e:
                print(f"  — ครั้งที่ {attempt}: เกิดข้อผิดพลาดในการเชื่อมต่อ: {e}")

            #พักก่อนยิงครั้งต่อไป
            await asyncio.sleep(0.2)

        # ------------------------------------------------
        # 1. ดึงสรุปคูปองส่วนตัว (เฉพาะของ MY_STUDENT_ID)
        # ------------------------------------------------
        print("\nกำลังดึงสรุปผลคูปองของตนเอง...")
        try:
            res = await client.get(f"{SERVER_URL}/my-coupons/{MY_STUDENT_ID}")
            if res.status_code == 200:
                summary = res.json()
                total = summary.get("total_claimed", 0)
                coupons = summary.get("claimed_coupons", [])
                print(f"สรุปผล [{MY_STUDENT_ID}]: ได้รับคูปองรวม {total} ใบ -> {coupons}")
            else:
                print(f"ดึงข้อมูลส่วนตัวไม่สำเร็จ Status Code: {res.status_code}")
        except Exception as e:
            print(f"เกิดข้อผิดพลาดในการดึงข้อมูลส่วนตัว: {e}")

        # ------------------------------------------------
        # 2. เพิ่มการดึงสรุปภาพรวมทั้งหมด (/summary)
        # ------------------------------------------------
        print("\n กำลังดึงสรุปภาพรวมคูปองทั้งหมดจาก Server (/summary)...")
        try:
            res = await client.get(f"{SERVER_URL}/summary")
            if res.status_code == 200:
                summary_all = res.json()
                rem_stock = summary_all.get("remaining_stock", "N/A")
                claims = summary_all.get("student_claims", {})

                print(f"จำนวนคูปองคงเหลือใน Server: {rem_stock} ใบ")
                print("รายการคูปองที่นักเรียนแต่ละคนได้รับ:")

                for sid, coupons in claims.items():
                    print(f"  - {sid}: ได้รับ {len(coupons)} ใบ -> {coupons}")

                # ตัวชี้วัดว่าเกิด Race Condition ขึ้นจริงหรือไม่
                issued = summary_all.get("total_issued", 0)
                stock = summary_all.get("total_coupons_in_stock", 0)
                over = summary_all.get("over_issued", 0)
                dup = summary_all.get("duplicated_coupons", [])

                print(f"\n[ตรวจสอบความถูกต้อง] แจกไปแล้ว {issued} ใบ จากสต็อกทั้งหมด {stock} ใบ")
                if over > 0 or dup:
                    print(f"  ผลลัพธ์ผิดพลาด: แจกเกินไป {over} ใบ | คูปองที่ซ้ำรหัส: {dup}")
                else:
                    print("  ผลลัพธ์ถูกต้อง: ไม่มีการแจกเกิน และไม่มีคูปองซ้ำรหัส")
            else:
                print(f"ดึงข้อมูลสรุปภาพรวมไม่สำเร็จ Status Code: {res.status_code}")
        except Exception as e:
            print(f"เกิดข้อผิดพลาดในการดึงสรุปภาพรวม: {e}")

if __name__ == "__main__":
    asyncio.run(hunt_coupons())
